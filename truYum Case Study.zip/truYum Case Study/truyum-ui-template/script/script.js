if( $('#dateOfLaunch').length )        
{
    $("#dateOfLaunch").datepicker({
        uiLibrary: "bootstrap4",
        format: "dd/mm/yyyy",
      });
}
      